import java.net.*;
import java.io.*;
import java.util.ArrayList;

public class Server
{
    private DatagramSocket sckt = new DatagramSocket(5001);
    private BufferedReader input =new BufferedReader(new InputStreamReader(System.in));
    private DatagramPacket iste, out;
    private byte[] byt;
    String gelen,giden,gelen2,giden2;
    ArrayList<String> kelimeler = new ArrayList<String>();
    String win = "Server kelime hatası yaptı.. Kazandınız.. Tebrikler..";
    String time = "Server zamanında cevaplayamadı.. Tebrikler.. Kazandınız..";

    public Server()throws SocketException
    {
        System.out.println("Server started");
        System.out.println("İlk kelime için Client bekleniyor.. Kullanılan kelimenin son iki harfinden kelime türetmeyi unutmayın!");
    }

    public void game()throws Exception
    {
        while(true)
        {
            byt = new byte[1200];
            iste = new DatagramPacket(byt, byt.length);
            sckt.receive(iste);
            byte[] data = new byte[iste.getLength()];
            System.arraycopy(iste.getData(), iste.getOffset(), data, 0, iste.getLength());
            gelen = new String(data);

            if (gelen.equals("Client kelime hatası yaptı.. Tebrikler.. Kazandınız..") || gelen.equals("Client zamanında cevaplayamadı.. Tebrikler.. Kazandınız.."))
            {
                System.out.println(gelen);
                break;
            }
            kelimeler.add(gelen);
            System.out.println("Gelen Kelime : " + gelen);
            System.out.println("10 saniye içinde kelimenizi yaziniz  : ");
            long ilktime = System.currentTimeMillis();
            giden = input.readLine();
            while(kelimeler.contains(giden))
            {
                ilktime = System.currentTimeMillis();
                System.out.println("Bu kelime daha önce kullanıldı.. Kelimenizi yaziniz  : ");
                giden = input.readLine();
            }

            while (giden.contains(" ") || giden.isEmpty())
            {
                ilktime = System.currentTimeMillis();
                System.out.println("Boş dizin gönderemezsiniz. Kelimenizi giriniz : ");
                giden = input.readLine();
            }

            long sontime = System.currentTimeMillis();
            long tme = sontime - ilktime;
            double sn = (double)tme/1000;

            if (sn>10.0)
            {
                System.out.println( sn + " saniyede yazarak 10 saniyeyi geçtiniz.. Kaybettiniz..");
                byt = time.getBytes();
                out = new DatagramPacket(byt, byt.length, iste.getAddress(), iste.getPort());
                sckt.send(out);
                break;
            }

            gelen2 = gelen.substring(gelen.length() - 2);
            giden2 = giden.substring(0, 2);

            if (gelen2.equals(giden2))
            {
                System.out.println("Sıranızı bekleyiniz ");
                kelimeler.add(giden);
                byt = giden.getBytes();
                out = new DatagramPacket(byt, byt.length, iste.getAddress(), iste.getPort());
                sckt.send(out);
            } else
            {
                System.out.println("Gelen kelimenin son iki harfini kullanamadınız.. Kaybettiniz..");
                byt = win.getBytes();
                out = new DatagramPacket(byt, byt.length, iste.getAddress(), iste.getPort());
                sckt.send(out);
                break;
            }
        }
    }
    public static void main(String[] arguments)throws Exception
    {
        Server server=new Server();
        server.game();
    }
}